plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.yamosaed.voice"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.yamosaed.voice"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

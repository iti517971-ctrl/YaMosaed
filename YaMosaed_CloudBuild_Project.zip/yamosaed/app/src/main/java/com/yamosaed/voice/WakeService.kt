package com.yamosaed.voice

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.provider.Settings
import android.net.Uri
import android.widget.Toast
import java.util.Locale

class WakeService : Service(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var wakeDetected = false
    private var restarting = false
    private lateinit var audio: AudioManager

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
        val notification = Notification.Builder(this, "ya_mosaed")
            .setContentTitle("يا مساعد")
            .setContentText("المساعد الصوتي يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, notification)
        startRecognition()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("ya_mosaed", "يا مساعد", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("خدمة التعرف على الكلام غير متاحة على هذا الهاتف")
            stopSelf()
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-YE")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            listening = true
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart()
        }
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { listening = false }

    override fun onPartialResults(partialResults: Bundle?) {
        val words = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        words?.firstOrNull()?.let { processText(it, partial = true) }
    }

    override fun onResults(results: Bundle?) {
        listening = false
        val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        words?.forEach { if (processText(it, partial = false)) return@forEach }
        scheduleRestart()
    }

    override fun onError(error: Int) {
        listening = false
        scheduleRestart()
    }

    private fun scheduleRestart() {
        if (restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            if (!listening) startRecognition()
        }, 700)
    }

    // Returns true when a command was handled.
    private fun processText(raw: String, partial: Boolean): Boolean {
        val text = raw.lowercase(Locale.ROOT)
            .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
            .replace("ى", "ي").trim()
        if (!wakeDetected) {
            if (text.contains("يا مساعد") || text.contains("يا مساعدة") || text.contains("يامساعد")) {
                wakeDetected = true
                val rest = text.substringAfter("يا مساعد", "").trim()
                if (rest.isNotBlank()) runCommand(rest)
                else toast("تفضل، اسمعك")
                if (!partial) wakeDetected = false
                return true
            }
            return false
        }
        if (!partial) {
            runCommand(text)
            wakeDetected = false
        }
        return true
    }

    private fun runCommand(command: String) {
        when {
            command.contains("ارفع الصوت") || command.contains("علي الصوت") || command.contains("زود الصوت") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            command.contains("خفض الصوت") || command.contains("وطي الصوت") || command.contains("نزل الصوت") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            command.contains("اكتم الصوت") || command.contains("صامت") ->
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            command.contains("كم الساعة") || command.contains("الوقت") ->
                toast("الساعة الآن " + java.text.SimpleDateFormat("h:mm a", Locale("ar")).format(java.util.Date()))
            command.contains("افتح يوتيوب") || command.contains("افتح youtube") ->
                openPackage("com.google.android.youtube")
            command.contains("افتح واتساب") || command.contains("افتح whatsapp") ->
                openPackage("com.whatsapp")
            command.contains("افتح الإعدادات") || command.contains("افتح الاعدادات") ->
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            command.contains("اتصل") || command.contains("اتصال") -> {
                val digits = command.filter { it.isDigit() || it == '+' }
                if (digits.isNotBlank()) {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else toast("قل: اتصل ثم رقم الهاتف")
            }
            command.contains("افتح") -> openByName(command.substringAfter("افتح").trim())
            else -> toast("لم أفهم الأمر. جرّب: ارفع الصوت أو افتح يوتيوب")
        }
    }

    private fun openPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else toast("التطبيق غير مثبت أو لا يمكن فتحه")
    }

    private fun openByName(name: String) {
        val mapping = mapOf(
            "الخرائط" to "com.google.android.apps.maps",
            "جوجل" to "com.google.android.googlequicksearchbox",
            "كروم" to "com.android.chrome",
            "الكاميرا" to "com.google.android.GoogleCamera",
            "تيليجرام" to "org.telegram.messenger",
            "تلجرام" to "org.telegram.messenger",
            "فيسبوك" to "com.facebook.katana",
            "انستقرام" to "com.instagram.android"
        )
        val pkg = mapping.entries.firstOrNull { name.contains(it.key) }?.value
        if (pkg != null) openPackage(pkg) else toast("ما عرفت التطبيق. جرّب اسم تطبيق مدعوم")
    }

    private fun toast(message: String) {
        android.os.Handler(mainLooper).post { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

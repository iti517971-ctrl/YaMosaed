package com.yamosaed.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val req = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "يا مساعد"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "مساعد صوتي عربي — نسخة تجريبية"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "تشغيل الاستماع"
            setOnClickListener { requestAndStart() }
        }
        val stop = Button(this).apply {
            text = "إيقاف الاستماع"
            setOnClickListener {
                stopService(Intent(this@MainActivity, WakeService::class.java))
                status.text = "تم إيقاف الاستماع"
            }
        }
        val note = TextView(this).apply {
            text = "قل: «يا مساعد» ثم الأمر. يعتمد العمل دون إنترنت على دعم خدمة التعرف الصوتي في هاتفك."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(note)
        setContentView(root)
    }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), req)
            return
        }
        startService(Intent(this, WakeService::class.java))
        status.text = "الاستماع مفعّل. قل: يا مساعد"
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == req && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            requestAndStart()
        } else {
            status.text = "يلزم السماح بالميكروفون لتشغيل المساعد"
        }
    }
}
